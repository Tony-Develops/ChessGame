package exceptions;

public class MovementException extends Exception{

	public MovementException(String message)
	{
		super(message);
	}
}
