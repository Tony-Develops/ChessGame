package tools;

public enum Type {
	White,
	Black,
}
