package main;

import login.Login;

public class Driver {
	
	public static void main(String[] args) 
	{
		Login login = new Login();
		login.run();
	}

}
