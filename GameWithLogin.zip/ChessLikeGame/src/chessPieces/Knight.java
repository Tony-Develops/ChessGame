package chessPieces;

import tools.Position;
import tools.Type;

public class Knight extends ChessPiece {

	public Knight(Position pos, Type type) {
		super(pos, type);
	}

	public Position[] calcPositions(int boardSizeX, int boardSizeY) {
		// This code needs to be modified to depend on type
		return null;
	}


}
