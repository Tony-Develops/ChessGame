package exceptions;

public class ChessPieceException extends Exception{
	
	public ChessPieceException(String message)
	{
		super(message);
	}
}
